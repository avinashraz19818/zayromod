MizanMod Studio update for the EXISTING /opt/mizanmod-full VPS installation.
Stop accepting new orders and finish builds first.
Run as root: python3 apply-update.py
Only manifest-listed files are installed. Existing env/signing keys, users/orders and uploaded designs are preserved. New unique catalog bundles are activated at 10 coins primary / 5 coins alternate.
The updater backs up the current database and changed files, stops only the full-platform service, runs tests/import and checks health. Failure triggers rollback. A later manual database restore can undo newer orders: review before restoring.
After success, as mizanmods in /opt/mizanmod-full: node --env-file=.env scripts/configure-bot.js
Refresh the browser / reopen the Telegram Mini App; send /start for the new bot welcome. Telegram controls native chat theme. Full Android/device acceptance remains pending.
